import "bootstrap/dist/css/bootstrap.css";
import type { AppProps } from "next/app";
import Head from "next/head";
import { Menu } from "../../componentes/Menu";

export default function Home({ Component, pageProps }: AppProps) {
  return (
    <>
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Loja Next</title>
      </Head>
      <Menu />
      <main className="container">
        <h1>Página inicial</h1>
      </main>
    </>
  );
}
