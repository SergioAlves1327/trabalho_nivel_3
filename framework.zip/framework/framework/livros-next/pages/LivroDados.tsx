import { NextPage } from "next";
import "bootstrap/dist/css/bootstrap.css";
import { ControleEditora } from "../classes/controle/ControleEditora";
import { Livro } from "../classes/modelo/Livro";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Head from "next/head";
import { Menu } from "../componentes/Menu";

const controleEditora = new ControleEditora();
const baseURL = "http://localhost:3000/api/livros";

const incluirLivro = async (livro: Livro) => {
  const response = await fetch(baseURL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(livro),
  });

  return response.ok;
};

const LivroDados: NextPage = () => {
  const router = useRouter();

  const opcoes = controleEditora.getEditoras().map((editora) => ({
    value: editora.codEditora,
    text: editora.nome,
  }));
  const [titulo, setTitulo] = useState("");
  const [resumo, setResumo] = useState("");
  const [autores, setAutores] = useState("");
  const [codEditora, setCodEditora] = useState(opcoes[0].value);

  const tratarCombo = (evento: React.ChangeEvent<HTMLSelectElement>) => {
    setCodEditora(Number(evento.target.value));
  };

  const incluir = async (evento: React.FormEvent<HTMLFormElement>) => {
    evento.preventDefault();
    const livro = new Livro(0, codEditora, titulo, resumo, autores.split("\n"));

    await incluirLivro(livro);

    router.push("/LivroLista");
  };

  return (
    <main className="container">
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Loja Next</title>
      </Head>
      <Menu />
      <h1>Dados do livro</h1>
      <form onSubmit={incluir}>
        <div className="form-group mb-2">
          <label htmlFor="titulo">Título</label>
          <input
            type="text"
            className="form-control"
            id="titulo"
            value={titulo}
            onChange={(event) => setTitulo(event.target.value)}
          />
        </div>
        <div className="form-group mb-2">
          <label htmlFor="resumo">Resumo</label>
          <textarea
            className="form-control"
            id="resumo"
            value={resumo}
            onChange={(event) => setResumo(event.target.value)}
          />
        </div>
        <div className="form-group mb-2">
          <label htmlFor="editora">Editora</label>
          <select
            className="form-control"
            id="editora"
            value={codEditora}
            onChange={tratarCombo}
          >
            {opcoes.map((opcao) => (
              <option key={opcao.value} value={opcao.value}>
                {opcao.text}
              </option>
            ))}
          </select>
        </div>
        <div className="form-group mb-2">
          <label htmlFor="autores">Autores (1 por linha)</label>
          <textarea
            rows={3}
            className="form-control"
            id="autores"
            value={autores}
            onChange={(event) => setAutores(event.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary">
          Salvar dados
        </button>
      </form>
    </main>
  );
};

export default LivroDados;
