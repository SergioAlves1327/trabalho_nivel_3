import { ControleEditora } from "../../../classes/controle/ControleEditora";
import { NextApiRequest, NextApiResponse } from "next";

export const controleEditora = new ControleEditora();

// eslint-disable-next-line import/no-anonymous-default-export
export default (req: NextApiRequest, res: NextApiResponse) => {
  if (req.statusCode === 405) {
    return res.status(405).json({ message: "Método não permitido" });
  }

  if (req.statusCode === 500) {
    return res.status(500).json({ message: "Erro interno no servidor" });
  }

  if (req.method === "GET") {
    return res.status(200).json(controleEditora.getEditoras());
  }
};
