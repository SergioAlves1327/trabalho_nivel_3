import type { NextPage } from "next";
import "bootstrap/dist/css/bootstrap.css";
import { Livro } from "../classes/modelo/Livro";
import { useEffect, useState } from "react";
import Head from "next/head";
import { Menu } from "../componentes/Menu";
import { LinhaLivro } from "../componentes/LinhaLivro";

const baseUrl = "http://localhost:3000/api/livros";

const obter = async () => {
  const response = await fetch(baseUrl);
  const livros = await response.json();
  return livros;
};

const excluirLivro = async (codigo: number) => {
  const response = await fetch(`${baseUrl}/${codigo}`, {
    method: "DELETE",
  });

  return response.ok;
};

const LivroLista: NextPage = () => {
  const [livros, setLivros] = useState<Livro[]>([]);
  const [carregado, setCarregado] = useState(false);

  useEffect(() => {
    obter().then((livros) => {
      setLivros(livros);
      setCarregado(true);
    });
  }, [carregado]);

  const excluir = async (codigo: number) => {
    await excluirLivro(codigo);
    setCarregado(false);
  };

  return (
    <div className="container">
      <Head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>Loja Next</title>
      </Head>
      <Menu />
      <main>
        <h1>Catálogo de livros</h1>
        <table className="table table-striped">
          <thead className="thead-dark bg-info">
            <tr className="bg-info">
              <th scope="col" className="bg-dark text-white">
                Título
              </th>
              <th scope="col" className="bg-dark text-white">
                Resumo
              </th>
              <th scope="col" className="bg-dark text-white">
                Editora
              </th>
              <th scope="col" className="bg-dark text-white">
                Autores
              </th>
            </tr>
          </thead>
          <tbody>
            {livros.map((livro) => (
              <LinhaLivro key={livro.codigo} livro={livro} excluir={excluir} />
            ))}
          </tbody>
        </table>
      </main>
    </div>
  );
};

export default LivroLista;
